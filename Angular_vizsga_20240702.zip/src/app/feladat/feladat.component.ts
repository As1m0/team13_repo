import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrl: './feladat.component.css'
})
export class FeladatComponent {

  VizsgaltSzam!: number;
  eredmenyek: string[] = [];
  listaStyle: string = "list-style-type: circle;"

  EredmenyMentes(): void {
    if (this.VizsgaltSzam == 2) {
      this.eredmenyek.push("A(z) " + this.VizsgaltSzam + " NEM prím");
    } else {
      let osztokSzama: number = 0;
      for (let i: number = 2; i < this.VizsgaltSzam; i++) {
        if (this.VizsgaltSzam % i === 0) {
          osztokSzama++;
        }
      }
      if (osztokSzama != 0) {
        this.eredmenyek.push("A(z) " + this.VizsgaltSzam + " NEM prím");
      } else {
        this.eredmenyek.push("A(z) " + this.VizsgaltSzam + " prím");
      }
    }
  }


}
