import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrl: './vizsgafeladat.component.css'
})
export class VizsgafeladatComponent {
  eredmenyek: any[] = [];
  testSuly: number = 76;
  magassag: number = 1.67;

  EredmenyMentes(): void {
    let TTI = this.testSuly / (this.magassag * this.magassag);
    let adatok = {
      TTI: Number(TTI.toFixed(2)),
      testsuly: this.testSuly,
      Magassag: this.magassag
    };
    this.eredmenyek.push(adatok);
  }
}